public class CalculateDiffSum {
    public static int sum(int a , int b){
        return a+b;

    }
    public static float sum(float a , float b){
        return a+b;

    }
    //check Prime number function 
    public static boolean isPrime(int n) {

        //corner case 
        if(n== 2){
            return true;
        }
        boolean isPrime = true;
        for(int i=2; i<=n-1; i++){
            if(n%2 == 0){
                isPrime = false;
                break;

            }
        }
        return isPrime;

    }
    public static void main(String[] args) {
        System.out.println(sum(2.2f, 2.5f));
        System.out.println(sum(4, 5));
        System.out.println(isPrime(5));
    }
}
