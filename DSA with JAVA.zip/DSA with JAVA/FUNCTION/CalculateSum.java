import java.util.*;
public class CalculateSum {
    public static void calculateSum(int num1, int num2){   //parameter or formal parameter
    
        int sum = num1+num2;
        System.out.println("Sum is "+ sum);

    }
    public static void main(String[] args) {
        System.out.println("Enter the value:");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        calculateSum(a, b);


        //argument or actual parameter

    }
}
