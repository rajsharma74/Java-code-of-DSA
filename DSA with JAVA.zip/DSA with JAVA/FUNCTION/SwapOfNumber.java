public class SwapOfNumber {
    public static void Swap(int a , int b){
        int temp = a;
        a  = b;
        b = temp;
        System.out.println("print by function method ");
        System.out.println("Value of a is :" + a);
        System.out.println("value of b is :" + b); 

    }
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        Swap(a,b);
        System.out.println("Print by main method"); // does not allow call by reference
        System.out.println("value of a is:"+a);
        System.out.println("Value od b is :"+b);

        
    }
}
