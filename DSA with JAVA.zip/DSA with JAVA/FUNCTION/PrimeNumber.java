public class PrimeNumber {
    public static boolean isPrime(int n){
        if(n==2){
            return true; 
        }
        for(int i=2; i<=Math.sqrt(n); i++){
            if(n%i == 0){
                return false;
            }

        }
        return true;
       
    }
    public static void PrimeIsrange(int n){
        for(int i=2; i<=n; i++){
           if(isPrime(i)){
            System.out.print(i+" ");
           }
        }
        System.out.println();
    }
    public static void BinaryToDeci(int binNum){
       int myNum = n;
        int pow =0;
        int decNum = 0;
        while(binNum > 0){
            int lastDigit = binNum % 10;
            decNum = decNum + (lastDigit * (int)Math.pow(2, pow));
            pow++;
            binNum = binNum%10;

        }
        System.out.println("Decimal of" + myNum + " ="+ decNum);

    }
    public static void main(String[] args) {
       // System.out.println(isPrime(20));
        //PrimeIsrange(20);
        BinaryToDeci(1010);
    }
}
