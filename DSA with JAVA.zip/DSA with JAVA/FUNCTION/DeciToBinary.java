public class DeciToBinary {
    public static void DeciBinary(int n){
        int myNum =n;
        int pow = 0;
        int BinNum =0;
        while(n>0){
            int rem = n%2;
            BinNum = BinNum + (rem * (int)Math.pow(10, pow));
            pow++;
            n = n/2;

        
        }
        System.out.println("Decimal of"+ myNum+ "="+ BinNum);
    }
    public static void main(String[] args) {
        DeciBinary(8);
        
    }
}
