public class factotials {
    
    public static int Factori(int n){
        int f = 1;
        for(int i =1; i<=n; i++){
            f = f * i;
            
        }
        return f;

    }
    public static int binCoeff(int n , int r){
       int  n_fact = Factori(n);
       int r_fact = Factori(r);
       int nmr_fact = Factori(n-r);

       int binCoeff = n_fact/(r_fact * nmr_fact);
       return binCoeff;

    }
    public static void main(String[] args) {
        System.out.println(Factori(5));
        System.out.println(binCoeff(5, 2));
    }
}
