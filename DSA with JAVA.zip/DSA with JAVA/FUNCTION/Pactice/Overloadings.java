public class Overloadings {
    public static int SumOf(int a , int b){
        return a+b;

    }
    public static float SumOf(float a , float b){
        return a+b;
    }
    public static void main(String[] args) {
        System.out.println(SumOf(12.4f , 34.6f));
        System.out.println(SumOf(023, 3));
        
    }
}
