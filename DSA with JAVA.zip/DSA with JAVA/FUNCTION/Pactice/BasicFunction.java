import java.util.*;
public class BasicFunction {
    public static void printHello(){
        System.out.println("Hello world");
        System.out.println("Hello world");
        System.out.println("Hello world");
    }
    public static int  SumOfNum(int num1 , int num2 ){
        int sum = num1 + num2;
        return sum;
    }
    public static void main(String[] args) {
        printHello();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sum = SumOfNum(a, b);
        System.out.println(sum);
        
    }
}
