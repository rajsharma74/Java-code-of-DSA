public class CallByValue {
    public static void Swap(int a , int b){
        int temp = a;
        a = b;
        b = temp;
        System.out.println("Value of A after Swap :"+ a);
        System.out.println("Value of B after swap : "+ b);

    }
    public static void main(String[] args) {
        int a =10;
        int b = 45;
        Swap(a, b);
        System.out.println("Value of A after Swap :"+ a);
        System.out.println("Value of B after swap : "+ b);

        
    }
}
