public class ProductOfNumber {
    public static int multiply(int a , int b){
        int product = a*b;
        return product;

    }
    public static void main(String[] args) {
        int a = 3;
        int b =5;
       int prob = multiply(a, b);
       System.out.println("multiply a*b:"+prob);
       int prob1 = multiply(10, 20);
       System.out.println("multiply of :"+ prob1);

    
    }
}
