public class AgainType {
    public static boolean CheckPrime(int n){
        if(n==2){
            return true;
        }
        for(int i=2; i<=Math.sqrt(n); i++){
            if(n%2 ==0){
                return false;
            }

        }
        return true;
    }
    public static void primeIsrange(int n){
        for(int i=2; i<=n; i++){
            if(CheckPrime(i)){
                System.out.print(i+" ");
            }
        }
        System.out.println();
    }
    public static void binToDec(int binNum){
        int myNum = binNum;
        int pow =0;
        int DecNum =0;
        while(binNum > 0){
            int LastDigit = binNum % 10;
            DecNum = DecNum + (LastDigit * (int)Math.pow(2, pow));

            pow++;
            binNum = binNum/10;

        }
        System.out.println("Decimal of "+myNum+" = "+ DecNum);
    }
    public static void DeciToBiny(int n){
        int myNum =n;
        int pow =0;
        int binarynum =0;
        while(n > 0){
            int rem = n%2 ;
            binarynum = binarynum + (int)(rem * Math.pow(10, pow) ) ;
            pow++;
            n = n/2;
        }
        System.out.println("Binary of " + myNum+ " = "+ binarynum);
    }
    public static void main(String[] args) {
        
        primeIsrange(100);
        binToDec(1010101);
        DeciToBiny(12);
    }
}
