public class Basic_02_Day {
    public static boolean CheckPrime(int n){
        if(n ==2){
            return true;
        }
        for(int i=2; i<=Math.sqrt(n); i++){
            if(n%2 == 0){
                return false;
            }
        }
        return true;
    }
    public static void primeIsrange(int n){
        for(int i=2; i<=n; i++){
            if(CheckPrime(i)){
                System.out.print(i+ " ");
            }
        }
        System.out.println();
    }
    public static void main(String[] args) {
        //System.out.println(CheckPrime(23));
        primeIsrange(20);
    }
}
