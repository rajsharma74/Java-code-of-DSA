public class Pattern_Rac {
    public static void Hollow_Ractangle(int rows , int cols){
        for(int i =1; i<=rows; i++){
            for(int j=1; j<=cols; j++){
                if(i==1 || i==rows || j==1 || j==cols){
                    System.out.print("*");
                }
                else{
                        System.out.print(" ");
                }
            }
                     System.out.println();

         }
     }
     public static void Pyramid(int n){
        for(int i =1; i<=n; i++){
            for(int j=1; j<= n-i; j++){
                System.out.print(" ");
            }
            for(int j=1; j<=i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        
     }
     public static void Inverted_Pyramid(int n){
        for(int i=1; i<=n; i++){
            for(int j =1; j<= n-i+1; j++){
                System.out.print(j+" ");
            }
            System.out.println();
        }
     }
     public static void Floyd(int n){
        char counter = 'A';
        for(int i=1; i<=n; i++){
            for(int j=1; j<=i; j++){
                System.out.print(counter + " ");
                counter++;

            }
            System.out.println();
        }
     }
    public static void main(String[] args) {
        Hollow_Ractangle(4, 5);
        Pyramid(4);
        Inverted_Pyramid(5);
        Floyd(5);
    }
}
