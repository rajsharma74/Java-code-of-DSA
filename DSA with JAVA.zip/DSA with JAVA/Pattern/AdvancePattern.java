public class AdvancePattern {
    public static void Tringle(int row , int col){
        for(int i =1; i<=row; i++){
            for(int j=1; j<=i; j++){
                if((i + j)%2== 0){
                    System.out.print("1");

                }
                else{
                    System.out.print("0");
                }
            }
            System.out.println();
        }
    }
    public static void Butterfly(int n){
        for(int i=1; i<=n; i++){
            //stats
            for(int j=1; j<=i; j++){
                System.out.print("*");
            }
            //Spaces
            for(int j=1; j<= 2*(n-i); j++){
                System.out.print(" ");
            }
            //spaces
            for(int j=1; j<=i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        for(int i=n; i>=1; i--){
              for(int j=1; j<=i; j++){
                System.out.print("*");
            }
            //Spaces
            for(int j=1; j<= 2*(n-i); j++){
                System.out.print(" ");
            }
            //spaces
            for(int j=1; j<=i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void Solid_Rhombus(int n){
        for(int i=1; i<=n; i++){
            for(int j=1; j<=n-i; j++){
                System.out.print(" ");
            }
            for(int j=1; j<=n; j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        //Tringle(5, 5);
        //Butterfly(5);
        Solid_Rhombus(5);
    } 
}
