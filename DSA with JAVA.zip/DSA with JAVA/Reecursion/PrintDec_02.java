public class PrintDec_02 {
    public static void PrintDec(int n ){
        if(n == 1){
            System.out.print(1);
            return;
        }
        System.out.print(n +" ");
        PrintDec(n-1);
    }
    public static void printInc(int n ){
        if(n == 1){
            System.out.print(1 + " ");
            return;
        }
        printInc(n-1);
        System.out.print(n +" ");

    }
    public static int Fact(int n){
        if(n==0){
            return 1;
        }
        int fac1 = Fact(n-1);
        int fac = n* Fact(n-1);
        return fac;
    }

    public static int sum(int n){
        if(n==1){
            return 1;
        }
        int sum1 = sum(n-1);
        int s = n + sum(n-1);
        return s;
    }

    public static int fab(int n){
        if(n==1 || n==0){
            return n;
        }
        int fb1 = fab(n-1);
        int fb2 = fab(n-2);
        int fb = fb1+fb2;
        return fb;
    }

    public static boolean isSorted(int arr[] , int i){
        if(i == arr.length-1){
            return true;
        }
        if(arr[i] > arr[i+1]){
            return false;
        }
        return isSorted(arr, i+1);
    }

    public static int FirstOccu(int arr[], int key, int i){
        if(i == arr.length){
            return -1;
        }
        if(arr[i] == key){
            return i;
        }
        return FirstOccu(arr, key, i+1);
    }
    public static void main(String[] args) {
       
        int arr[]  = { 1, 3, 5,7, 8};
        //PrintDec(10);
       //printInc(10);
       //System.out.println(isSorted(arr, 0));
       System.out.println(FirstOccu(arr, 5, 0));
    }
    
}
