public class Ques_03 {
    public static int sum(int n){
        
    }
    public static void main(String[] args) {
        
    }
}
