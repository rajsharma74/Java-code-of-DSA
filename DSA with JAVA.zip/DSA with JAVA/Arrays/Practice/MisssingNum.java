import java.util.*;

public class MisssingNum {
    public static void missing(int arr[], int n) {
        int sum1 = 0;
        int sum2 = 0;

        for (int i = 0; i < arr.length; i++) {
            sum1 = sum1 + arr[i];
        }

        for (int i = 0; i < n; i++) {
            sum2 = sum2 + i;
        }

        int missingNumber = (sum2 - sum1);
        System.out.println("Missing Number: " + missingNumber);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        int n = sc.nextInt();
        int arr[] = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }

        missing(arr, n);
    }
}
