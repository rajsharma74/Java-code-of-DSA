public class Ch_11_BasicFunction {
    public static void printhelloworld(){
        System.out.println("Hello world");
        System.out.println("Hello world");
        System.out.println("Hello world");
    }
    public static int sumofnumber(){
        int a;
        a = 5+6;
    //System.out.println(a);
        return a;
    }
    public static void main(String[] args) {
        printhelloworld();
        sumofnumber();

    }
}
