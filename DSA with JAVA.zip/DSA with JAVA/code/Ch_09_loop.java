public class Ch_09_loop {
    public static void main(String[] args) {
        int i =1;
        while(i<=5){
            System.out.println("hello world");
            i++;
        }
    }
}
