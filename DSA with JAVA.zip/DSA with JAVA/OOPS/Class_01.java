public class Class_01 {
    public static void main(String[] args) {
        Horses h = new Horses();
        h.eat();
        h.walk();

        Chiken c = new Chiken();
        c.eat();
        c.walk();
    }
}

abstract class Animal{
    void eat(){
        System.out.println("eats all items");
    }
    abstract void walk();
}
class Horses extends Animal{
    void walk(){
        System.out.println("walk with 4 legs");
    }
}
class Chiken extends Horses{
    void walk(){
        System.out.println("wall with 2legs");
    }
}
