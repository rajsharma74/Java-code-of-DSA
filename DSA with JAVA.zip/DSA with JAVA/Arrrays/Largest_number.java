import java.util.*;
public class largest_Number {
    public static void largest_num(int number[]){
        int largest = Integer.MIN_VALUE;
        for(int i=0; i<number.length; i++){
            if(largest < number[i]){
                largest = number[i];
            }
            return largest;
        }
    }
    public static void main(String[] args) {
        int number[] = (2, 4, 5, 6, 7, 8, 9, 9);
        System.out.println("Largest number is " + largest_Number(number));
    }
}
