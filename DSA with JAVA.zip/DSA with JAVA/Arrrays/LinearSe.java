public class LinearSe {
    public static int linearsearch(int marks[] , int key){
        for(int i=0; i<marks.length; i++){
            if(key == marks[i]){
                return i;

            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int marks[] = {3, 4, 5, 6, 8};
        int key = 4;
        int index = linearsearch(marks, key);
        if(index == -1){
            System.out.println("not found");
        }
        else{
            System.out.println(" Yes its found in given array");
        }
    }
}
