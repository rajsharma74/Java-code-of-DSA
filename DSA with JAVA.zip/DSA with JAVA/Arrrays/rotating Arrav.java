public class RotatingAarav {

    public static void main(String[] args) {
        rotateAarav();
    }

    static void rotateAarav() {
        String word = "AARAV";

        while (true) {
            clearConsole();
            System.out.println(word);
            sleep(500); // Adjust the sleep duration as needed
            word = rotateWord(word);
        }
    }

    static String rotateWord(String word) {
        // Rotate the word by moving the last character to the beginning
        return word.charAt(word.length() - 1) + word.substring(0, word.length() - 1);
    }

    static void clearConsole() {
        // Clear console screen for a smoother rotation effect
        try {
            final String os = System.getProperty("os.name");

            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
