public class LargestElement {
    public static int largestele(int marks[]){
        int max = Integer.MIN_VALUE;
        for(int i=0; i<marks.length; i++){
            if(max < marks[i]){
                max = marks[i];
            }
        }
        return max;

    }
    public static void main(String[] args) {
        int marks[] = {34, 67, 89 ,87, 90, 100};
        System.out.println("largest element "+ largestele(marks));
    }
}
