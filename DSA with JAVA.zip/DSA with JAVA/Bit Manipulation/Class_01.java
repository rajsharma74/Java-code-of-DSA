public class Class_01 {
    public static int GetSet(int n , int i){
        int Bitmask = 1<<i;
        if((n & Bitmask) == 0){
            return 0;
        }
        else{

        
        return 1;
        }
    }

    public static int SetGet(int n , int i){
        int Bitmask = 1<<i;
        return n|Bitmask;
    }
    public static void main(String[] args) {
        //System.out.println(GetSet(10, 2));
        System.out.println(SetGet(10, 2));
        
    }
}
